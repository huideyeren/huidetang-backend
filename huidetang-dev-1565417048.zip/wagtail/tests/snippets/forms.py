from wagtail.admin.forms import WagtailAdminModelForm


class FancySnippetForm(WagtailAdminModelForm):
    """
    A custom form class for FancySnippets in the admin
    """
