Wagtail is an open source content management system built on Django, with a strong community and commercial support. It’s focused on user experience, and offers precise control for designers and developers.

For more details, see https://wagtail.io, http://docs.wagtail.io and https://github.com/wagtail/wagtail/.

