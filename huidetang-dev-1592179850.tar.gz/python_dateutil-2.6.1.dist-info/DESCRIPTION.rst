
The dateutil module provides powerful extensions to the
datetime module available in the Python standard library.


